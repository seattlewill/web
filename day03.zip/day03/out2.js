function add(){
    alert('더하기 기능 처리후 결과 창')
}
function minus(){
    alert('빼기 기능 처리후 결과 창')
}